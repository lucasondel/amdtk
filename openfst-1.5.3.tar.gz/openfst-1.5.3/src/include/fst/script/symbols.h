// See www.openfst.org for extensive documentation on this weighted
// finite-state transducer library.

#ifndef FST_SCRIPT_SYMBOLS_H_
#define FST_SCRIPT_SYMBOLS_H_

#endif  // FST_SCRIPT_SYMBOLS_H_
